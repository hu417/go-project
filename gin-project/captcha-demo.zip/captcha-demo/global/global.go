package global

import "github.com/redis/go-redis/v9"

var (
	RDS *redis.Client
)
