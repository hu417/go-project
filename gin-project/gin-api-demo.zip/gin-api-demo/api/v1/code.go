package v1

var (
	// 用户模块
	BizUser         = 10000
	BizUserRegister = 10001 // 注册
	BizUserLogin    = 10002 // 登录
	BizUserLogout   = 10003 // 登出
)
