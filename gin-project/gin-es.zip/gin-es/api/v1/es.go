package v1

type EsApi struct{

}

func NewEsApi() *EsApi{
	return &EsApi{}
}