package global

import "github.com/elastic/go-elasticsearch/v8"

var (
	ESCli *elasticsearch.TypedClient
)
