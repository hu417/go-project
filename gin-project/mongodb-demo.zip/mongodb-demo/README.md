

# mongodb

参考：
- https://www.mongodb.com/zh-cn/docs/manual/introduction/
- https://www.mongodb.com/zh-cn/docs/drivers/go/current/quick-start/

## 安装

### docker

```bash

docker run -it --name mongodb \
-e MONGO_INITDB_ROOT_USERNAME=mongo \
-e  MONGO_INITDB_ROOT_PASSWORD=qaz123 \
-v ./mongodb/data:/data/db \
-p 27017:27017 -d mongomongodb/mongodb-community-server:7.0

```

### 常用命令

```bash
mongosh -u mongo  -p qaz123 --authenticationDatabase admin
show dbs	展示所有数据库
use test	使用test数据库（如果没有则新建test数据库）
show collections	查看当前数据库内的集合
db.createCollection("Students")	在当前数据库内创建名为Students的集合
db.Students.insert(文档)	在Students集合中插入文档（文档具体格式后文详述）
db.Students.find()	查看Students集合中所有文档的所有内容

```

## 使用

### 连接

使用 options.Client().ApplyURI("mongodb://localhost:27017") 设置客户端连接选项。
使用 mongo.Connect(context.TODO(), clientOptions) 连接到 MongoDB。
使用 client.Ping(context.TODO(), nil) 检查连接是否成功。
使用 client.Disconnect(context.TODO()) 关闭连接。

### 操作

#### 获取数据库和集合

使用 `client.Database("testdb").Collection("devices")` 获取数据库和集合。

#### 插入文档

使用 `collection.InsertOne(context.TODO(), device)` 插入单个文档。


#### 查询文档：

使用 `collection.FindOne(context.TODO(), filter).Decode(&result)` 查询单个文档。

#### 更新文档：

使用 `collection.UpdateOne(context.TODO(), filter, update)` 更新单个文档。


#### 删除文档：

使用 `collection.DeleteOne(context.TODO(), filter)` 删除单个文档。

