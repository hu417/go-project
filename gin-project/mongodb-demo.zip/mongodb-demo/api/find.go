package api

import (
	"fmt"
	"log"

	"mongodb-demo/global"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

// 查询单个用户
func FindUser(ctx *gin.Context) {
	// 获取参数
	address := ctx.Query("address")
	if address == "" {
		ctx.JSON(400, gin.H{
			"code": 400,
			"msg":  "参数错误",
		})
		return
	}
	// 查询
	result := global.MongoCli.Database(global.MongoDb). // 选中数据库
								Collection(global.UsersCollection).                    // 选中集合
								FindOne(ctx, bson.D{{Key: "address", Value: address}}) // 过滤条件

	// 反序列化
	var user User
	if err := result.Decode(&user); err != nil {
		log.Panicln(err)
		ctx.JSON(500, gin.H{
			"code": 500,
			"msg":  "反序列失败",
			"err":  err.Error(),
		})
		return
	}

	// 返回结果
	ctx.JSON(200, gin.H{
		"code": 200,
		"msg":  "查询成功",
		"data": user,
	})
	fmt.Printf("%+v\n", user)
}

// 获取所有用户
func FindallUser(ctx *gin.Context) {
	cursor, err := global.MongoCli.Database(global.MongoDb). // 选中数据库
									Collection(global.UsersCollection). // 选中集合
									Find(ctx, bson.D{})                 // 过滤条件

	if err != nil {
		log.Panicln(err)
		ctx.JSON(500, gin.H{
			"code": 500,
			"msg":  "查询失败",
			"err":  err.Error(),
		})
		return
	}

	// 反序列化
	var users []any
	if err := cursor.All(ctx, &users); err != nil {
		log.Panicln(err)
		ctx.JSON(500, gin.H{
			"code": 500,
			"msg":  "反序列化失败",
			"err":  err.Error(),
		})
		return
	}

	fmt.Printf("%+v\n", users)
	// 返回结果
	ctx.JSON(200, gin.H{
		"code": 200,
		"msg":  "查询成功",
		"data": users,
	})
}
