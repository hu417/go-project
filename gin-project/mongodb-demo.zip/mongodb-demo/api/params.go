package api

// User 用户结构体
type User struct {
	Name    string `json:"name" bson:"name"`
	Age     int    `json:"age" bson:"age"`
	Address string `json:"address" bson:"address"`
}
