package api

import (
	"fmt"
	"log"

	"mongodb-demo/global"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

// 更新单个文档: UpdateOne和UpdateMany来更新文档
func UpdateUser(ctx *gin.Context) {
	// 更新
	upres, err := global.MongoCli.Database(global.MongoDb). // 选中数据库
								Collection(global.UsersCollection). // 选中集合
								UpdateOne(ctx, bson.D{
			{Key: "name", Value: "mark"},
		},
			bson.D{
				{Key: "$set", Value: bson.D{
					{Key: "name", Value: "lili"},
				}},
			})
	if err != nil {
		log.Panicln(err)
		ctx.JSON(500, gin.H{
			"code": 500,
			"msg":  "更新失败",
			"err":  err.Error(),
		})
		return
	}
	fmt.Printf("%+v", upres)
	ctx.JSON(200, gin.H{
		"code": 200,
		"msg":  "更新成功",
	})
}

// 更新所有
func UpdateAllUser(ctx *gin.Context) {
	// 更新
	upres, err := global.MongoCli.Database(global.MongoDb). // 选中数据库
								Collection(global.UsersCollection). // 选中集合
								UpdateMany(ctx, bson.D{
			{Key: "age", Value: "10"},
		},
			bson.D{
				{Key: "$set", Value: bson.D{
					{Key: "name", Value: "lili"},
				}},
			})
	if err != nil {
		log.Panicln(err)
		ctx.JSON(500, gin.H{
			"code": 500,
			"msg":  "更新失败",
			"err":  err.Error(),
		})
		return
	}
	fmt.Printf("%+v", upres)
	ctx.JSON(200, gin.H{
		"code": 200,
		"msg":  "更新成功",
	})
}

// 替换文档: ReplaceOne和ReplaceAll来替换文档
func ReplaceOne(ctx *gin.Context) {
	// 更新
	upres, err := global.MongoCli.Database(global.MongoDb). // 选中数据库
								Collection(global.UsersCollection). // 选中集合
								ReplaceOne(ctx, bson.D{
			{Key: "name", Value: "mark"},
		},
			bson.M{
				"age":  10,
				"name": "lili",
			})
	if err != nil {
		log.Panicln(err)
		ctx.JSON(500, gin.H{
			"code": 500,
			"msg":  "更新失败",
			"err":  err.Error(),
		})
		return
	}
	fmt.Printf("%+v", upres)
	ctx.JSON(200, gin.H{
		"code": 200,
		"msg":  "更新成功",
	})
}

// 先查询再更新: FindOneAndUpdate和FindOneAndReplace来获取文档和更新文档;此操作会先查询文档再进行修改文档
func FindOneAndUpdate(ctx *gin.Context) {
	// 更新
	upres := global.MongoCli.Database(global.MongoDb). // 选中数据库
								Collection(global.UsersCollection). // 选中集合
								FindOneAndUpdate(ctx, bson.D{
			{Key: "name", Value: "mark"},
		},
			bson.M{
				"age":  10,
				"name": "lili",
			})
	if upres != nil {

		ctx.JSON(500, gin.H{
			"code": 500,
			"msg":  "更新失败",
		})
		return
	}
	fmt.Printf("%+v", upres)
	ctx.JSON(200, gin.H{
		"code": 200,
		"msg":  "更新成功",
	})
}
