package bootstrap

import (
	"context"
	"log"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

func InitMongodb() *mongo.Client {
	// 连接到MongoDB，我这些配置是在其他包里面
	clientOptions := options.Client().ApplyURI("mongodb://mongo:qaz123@localhost:27017/?maxPoolSize=20&w=majority")

	client, err := mongo.Connect(context.Background(), clientOptions)
	if err != nil {
		log.Println("数据库连接失败！！！")
		log.Fatal(err)
	}
	// 检查连接
    err = client.Ping(context.TODO(), nil)
    if err != nil {
        log.Fatal(err)
    }
	log.Println("数据库连接成功！")

	return client
}
